import "./App.css";
import Pokeapi from "./components/Pokeapi";

function App() {
	return (
		<div className="App">
			<Pokeapi />
		</div>
	);
}

export default App;
