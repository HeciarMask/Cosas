<?php
include('funciones.php');
cabecera('Alumnos');
echo "<div id=\"contenido\">";
	echo "<img src='tablas.jpg'>";
		echo "</div>";
		pie();
?>
