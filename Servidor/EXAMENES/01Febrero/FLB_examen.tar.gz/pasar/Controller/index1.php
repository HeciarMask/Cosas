﻿<?php
require_once('..\view\index1.php');

?>
