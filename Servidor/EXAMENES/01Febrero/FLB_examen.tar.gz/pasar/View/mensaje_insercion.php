﻿<?php
require_once('..\view\funciones.php');
cabecera('Práctica 4');
echo '<h2>Resultado Inserción</h2>';
echo "<br>" . $errores;
pie();
?>