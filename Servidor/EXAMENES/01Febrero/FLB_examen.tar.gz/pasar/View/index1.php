﻿<?php
require_once('..\view\funciones.php');
cabecera('Práctica 4');
echo "<div id=contenido>";
echo "<h1>MVC</h1>";
echo "</div>";
		pie();
?>
