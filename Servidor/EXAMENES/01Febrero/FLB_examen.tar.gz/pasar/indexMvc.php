<?php
header("Location: Controller/index1.php");
?>