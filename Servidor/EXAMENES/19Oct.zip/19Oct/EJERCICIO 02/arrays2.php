
<?php
$generos=array(
"SciFi"=>"Ciencia Ficción",
"Drama"=>"Drama",
"Adventure"=>"Aventuras",
"War"=>"Bélica",
"Comedy"=>"Comedia",
"Horror"=>"Miedo",
"Action"=>"Acción",
"Kids"=>"Infantil");
$filmes=array(
			"Bruce Almighty"=>array("genero"=>"Comedy","fecha"=>"2014"),
			"Office Space"	=>array("genero"=>"Comedy","fecha"=>"1999"),
			"Grand Canyon"	=>array("genero"=>"Drama","fecha"=>"1991"),
			"Pesadilla en Elm Street"=>array("genero"=>"Horror","fecha"=>"1984"),
			"Liberad a Willy"=>array("genero"=>"Kids","fecha"=>"1993"),
			"Solo en casa"  =>array("genero"=>"Kids","fecha"=>"1990"),
			"Planeta Rojo"	=>array("genero"=>"SciFi","fecha"=>"2000"),
			"La matanza de Texas"=>array("genero"=>"Horror","fecha"=>"1974"),
			"Screem"=>array("genero"=>"Horror","fecha"=>"1996")
			
			);
/* echo "<pre>";
print_r($generos);
echo "</pre>";

echo "<pre>";
print_r($filmes);
echo "</pre>"; */

?>
