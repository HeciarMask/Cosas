<?php
$notas = array(
'Miguel' => array('Matematicas'=>5, 'Tecnologia'=>5, 'Historia'=>6, 'Ingles'=>8),
'Ana' => array('Matematicas'=>7, 'Ingles'=>8, 'Lengua'=>6,  'Fisica'=>9, 'Historia'=>5),
'Luis' => array('Matematicas'=>4, 'Tecnologia'=>4, 'Lengua'=>5,  'Fisica'=>4, 'Historia'=>7),
'Maria' => array('Matematicas'=>6, 'Tecnologia'=>5, 'Historia'=>6, 'Ingles'=>4),
'Antonio' => array('Matematicas'=>4, 'Tecnologia'=>5, 'Lengua'=>5,  'Fisica'=>4, 'Historia'=>4, 'Ingles'=>6),
'Raul' => array('Matematicas'=>4, 'Tecnologia'=>5, 'Lengua'=>7,  'Fisica'=>5, 'Historia'=>6, 'Ingles'=>8)
);
?>