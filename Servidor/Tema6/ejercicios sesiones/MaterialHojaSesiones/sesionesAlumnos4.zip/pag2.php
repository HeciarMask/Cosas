<?php 
echo "<form method='POST' action='pag1.php'>";
echo " Las cabeceras se han cambiado a tamaño:";
echo "<a href='pag1.php'>Ir a página 1</a>";
?>