<?php 
$arrayTamaños=array(1=>"Encabezado 1",2=>"Encabezado 2",3=>"Encabezado 3",4=>"Encabezado 4");
echo "<form method='POST' ACTION='pag2.php'>
Nuevo tamaño:";
echo "</select><input type='submit' VALUE='Cambiar'></form>";
echo "<p><p><form method='POST' ACTION='pag3.php'>
<input type='submit' VALUE='Inicializar'></form>";
?>