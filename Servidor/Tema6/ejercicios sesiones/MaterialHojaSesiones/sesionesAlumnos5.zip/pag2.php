<?php
echo "si se seleccionó añadir<br>";


	echo "<table><form action='añadir.php' method='POST'>";
	echo "<tr><td>Idioma</td><td><input type='text' name='idioma'></td></tr>";
	echo "<tr><td>Nivel</td><td><input type='text' name='nivel'></td></tr>";
	echo "<tr><td colspan='2'><input type='submit' name='boton' value=Envío></td></tr></form></table>";

echo "si se selecionó cambiar<br>";
	echo "<table><form action='cambiar.php' method='POST'>";
	echo "<tr><td>Seleccione idioma</td><td><select name='idioma'>";
	echo "</td></tr><tr><td colspan='2'><input type='submit' name='boton' value=Envío></td></tr></form></table>";

	


?>