<?php
//si no se ha pulsado enviar pido el nuevo valor de nivel  
	echo "<table><form  method='POST'>";
	echo "<tr><td>Idioma</td><td>"."-------"."</td></tr>";
	echo "<tr><td>Nivel</td><td><input type='text' name='nivel' value="."--------"."></td></tr>";
	echo "<tr><td colspan='2'><input type='submit' name='enviar' value=enviar></td></tr></form></table>";
// si se ha pulsado enviar actualizo la variable de sesión y vuelvo a la página inicial


	//header("Location:pag1.php");

	


?>