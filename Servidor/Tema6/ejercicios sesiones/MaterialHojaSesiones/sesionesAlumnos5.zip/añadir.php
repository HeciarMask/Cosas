<?php
//añade los datos a la variable de sesión
header("Location:pag1.php");
?>