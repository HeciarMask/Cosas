<?php
/*a primera vez cargar una variable de sesión con 
el siguiente  array("ingles"=>9, "aleman"=>3, "frances"=>7,	"ruso"=>4) y mostrarla en la siguiente tabla html*/
echo "<table >";
echo "<tr><th>Idioma</th><th>Nivel</th></tr>";

echo "<form action='pag2.php' method='POST'>";
echo "<tr><td colspan='2'><b>Menú de opciones</b></td></tr>";
echo "<tr><td colspan='2'><input type='radio' name='opcion' value=1>Añadir</td></tr>";
echo "<tr><td colspan='2'><input type='radio' name='opcion' value=2>Cambiar</td></tr>";
echo "<tr><td colspan='2'><input type='submit' name='boton' value=Envío></td></tr></TABLE></FORM>";
?>